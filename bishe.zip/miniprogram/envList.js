const envList = [{"envId":"huanjing1-4gxaab48492dde9e","alias":"huanjing1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}