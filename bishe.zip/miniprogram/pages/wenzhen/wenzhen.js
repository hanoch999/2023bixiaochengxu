// pages/wenzhen/wenzhen.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    hight:null,
    show:false,
    inputwidth:'90%',
    msg:'',
    msgbox:[],
    loadingHidden:true,
    bing:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad:async function() {
    var winHeight = wx.getSystemInfoSync().windowHeight //设置变量存放屏幕高度值
    this.setData({
        hight:winHeight-150//传递值
    })
    db.collection('bing').get().then(res =>{
      this.setData({
        bing:res.data
      })
    })
    let that = this  //建议小白以后都这样做，不然真的会出现一些弱智的问题，懂得都懂。。
    const c = db.collection("bing"); //获取集合中记录的总数
    const total = await (await c.count()).total
    const batchTimes = Math.ceil(total / 20)
    console.log(batchTimes) //计算需要获取几次  比如你有36条数据就要获取两次 第一次20条第二次16条
    let arraypro = [] // 定义空数组 用来存储每一次获取到的记录 
    let x = 0 //这是一个标识每次循环就+1 当x等于batchTimes 说明已经到了最后一次获取数据的时候
    //没错，循环查询，看着就觉得很影响性能，但是么的办法。
    for (let i = 0; i < batchTimes; i++) {
    //分组获取
      db.collection("bing").skip(i * 20).get({
        success: function (res) {
          x += 1
          // 20个20个的获取 最后一次不够20 那就是剩下的
          for (let j = 0; j < res.data.length; j++) {
            arraypro.push(res.data[j])
          }
          //判断是否是最后一次，如果是说明已经不用再继续获取了，这时候就可以赋值了
          if (x == batchTimes) {
            that.setData({
              bing: arraypro
            })
          }
        }
      })
    }
  },
  write:function(e){
    let that = this
    that.setData({
      inputwidth:'80%',
      show:true
    })
  },
  aa:function(){},
  fasong:function(e){
    let that = this
    that.setData({
      inputwidth:'80%',
      show:false
    })
    if(that.data.msg){
      var mymsg = that.data.msg;
      that.data.msgbox.push(mymsg)
    }
    this
  },
  sendMsg:function(){
    var that =this
    let bingg= that.data.bing
    console.log(bingg)
    // 判断用户是否输入了值
    if(that.data.msg) {
      // 缓存用户输入的值
      var myMsg = that.data.msg;
      console.log(myMsg);
      // 自定义对象
      var myObj = {
        msg:myMsg,
        isMine:true  //用于判断是我的聊天还是他人的聊天
      }
      that.data.msgbox.push(myObj);
      that.setData({
        msg:"", //再次设置为空，达到输入框发送聊天后清空
        msgbox:that.data.msgbox,
      })
      var arr = [];
      let tezheng = []
      let mayname = ''
      let leiid = ''
      //特征判断
      for(var index in bingg){
        var string = bingg[index].symptom
        var num = string.indexOf(myMsg)
        if(num !=-1){
          console.log('456',bingg[index].rightname)
          console.log(bingg[index].leiid)
          tezheng.push(bingg[index].rightname)
          leiid=bingg[index].leiid
        }
      }
      //如果特征为0则对分类症状进行判断
      if(tezheng.length==0){
        for(var index in bingg){
          var string = bingg[index].rightname
          var num = string.indexOf(myMsg)
          if(num !=-1){//判断是否和病症一样
            console.log('77',bingg[index].rightname)
            mayname= bingg[index].rightname
            console.log(mayname)
            var system = {
              msg:'您输入的症状为：'+mayname,
              isMine:false
            }
          }else if(num ==-1){
            var system = {
              msg:'目前不能查询到您说描述的问题',
              isMine:false
            }
          }
        }
      }else{//如果特征部不为0
        var system = {
          msg:tezheng,
          isMine:false
        }
      }
      if(leiid !=''){
        console.log('可能的病',leiid)
      }
      that.data.msgbox.push(system);
      that.setData({
        msgbox:that.data.msgbox
      })
      console.log(that.data.msgbox)
    }
  },
  jieshu:function(){
    wx.showModal({
      title: '你确定要结束本次对话吗',
      content: '',
      complete: (res) => {
        if (res.cancel) {
          
        }
    
        if (res.confirm) {
          let dataTime
          let yy = new Date().getFullYear()
          let mm = new Date().getMonth()+1
          let dd = new Date().getDate()
          let hh = new Date().getHours()
          let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
            new Date().getMinutes()
          let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
            new Date().getSeconds()
            dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`;
          console.log(dataTime)
          db.collection("wenzhen").add({
            data: {
              dataTime:dataTime,
              msgbox:this.data.msgbox
            }
          })
          .then(res => {
            console.log(res)
            this.onShow()
            wx.showToast({
              title: "插入成功",
              icon: "success"
            })
            
          })
          .catch(err => {
            console.log(err)
            wx.showToast({
              title: "插入失败",
              icon: "error"
            })
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})