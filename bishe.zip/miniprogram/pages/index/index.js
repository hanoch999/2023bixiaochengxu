// pages/index/index.js
const db = wx.cloud.database()
var app = getApp()
app.globalData.cid
app.globalData.goodid
Page({
    /**
     * 页面的初始数据
     */
    data: {
        product:[],
        fenlei:[],
        // 轮播图开始
        bannerList: [
            'cloud://huanjing1-4gxaab48492dde9e.6875-huanjing1-4gxaab48492dde9e-1305410126/推荐列表/pic(4)2022030411113523.jpg',
            'cloud://huanjing1-4gxaab48492dde9e.6875-huanjing1-4gxaab48492dde9e-1305410126/推荐列表/201707311448547006860.jpg',
            'cloud://huanjing1-4gxaab48492dde9e.6875-huanjing1-4gxaab48492dde9e-1305410126/推荐列表/v2-fc28af041d11e936c9bfd3df3e75c7d3_1440w.jpg',
            'cloud://huanjing1-4gxaab48492dde9e.6875-huanjing1-4gxaab48492dde9e-1305410126/推荐列表/20220325171424_451.jpg' 
          ],
          indicatorDots: true,  //是否显示面板指示点
          autoplay: true,      //是否自动切换
          interval: 2000,       //自动切换时间间隔
          duration: 300,       //滑动动画时长
          inputShowed: false,
          inputVal: "",
          // 轮播图结束
                  //商品列表开始
        pro_list:[],
        //商品列表结束
        search_list:[],
        search_case:false,
        num:20,
        code:[],
        loadingHidden: true,
        no_scroll: false
    },
    search_case_close(){
        this.setData({
            search_case:false
        })
    },
    //页面上拉触底事件
    onReachBottom:function(){
        
    },
 
 
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad:async function() {
      // 分类开始
      var that = this;
      that.createshu()
      const db = wx.cloud.database({
        //这个是环境ID不是环境名称     
        env: 'huanjing1-4gxaab48492dde9e'
      })
      db.collection('tuijian').get({
        success:function(res){
          console.log('分类获取成功',res.data)
          that.setData({
            fenlei:res.data
          })
        },
        fail:function(res){
          console.log('分类获取失败',res)
        }
      })
        // 分类结束
        // 产品展示开始
        const c = db.collection("goodss"); //获取集合中记录的总数
        const total = await (await c.count()).total
        const batchTimes = Math.ceil(total / 20)
        console.log(batchTimes) //计算需要获取几次  比如你有36条数据就要获取两次 第一次20条第二次16条
        let arraypro = [] // 定义空数组 用来存储每一次获取到的记录 
        let x = 0 //这是一个标识每次循环就+1 当x等于batchTimes 说明已经到了最后一次获取数据的时候
        //没错，循环查询，看着就觉得很影响性能，但是么的办法。
        for (let i = 0; i < batchTimes; i++) {
        //分组获取
          db.collection("goodss").skip(i * 20).get({
            success: function (res) {
              x += 1
              // 20个20个的获取 最后一次不够20 那就是剩下的
              for (let j = 0; j < res.data.length; j++) {
                arraypro.push(res.data[j])
              }
              //判断是否是最后一次，如果是说明已经不用再继续获取了，这时候就可以赋值了
              if (x == batchTimes) {
                that.setData({
                  product: arraypro
                })
              }
              that.createcode()
            }
          })
        }
    },
    aaa(){
      wx.navigateTo({
        url: '../ceshi/ceshi',
      })
    },
    goto:function(e){
      var mid=e.currentTarget.dataset.lid
      console.log(mid)
      app.globalData.cid=e.currentTarget.dataset.lid
      console.log(app.globalData.cid)
      wx.navigateTo({
        url: '/pages/fenlei1/fenlei1'
      })
    },
    detail:function(even){
      var zid = even.currentTarget.dataset.id
      var zimg = even.currentTarget.dataset.imgurl
      var zprice = even.currentTarget.dataset.price
      let gooddd = []
      gooddd.push({
        product_id:zid,
        imgurl:zimg,
        price:zprice
      })
      console.log("商品id：",gooddd)
      wx.navigateTo({
        url: '/pages/good/good?id='+zid,
      })
      app.globalData.goodid=even.currentTarget.dataset.id
      console.log("商品全局变量：",app.globalData.goodid)
    },
    createshu(){
      let numbers = [];
      /*生成随机数并记录*/
      while (numbers.length < 10) {
        const num = Math.floor(Math.random() *171) + 1;
        if (numbers.indexOf(num) === -1) {
          numbers.push({
            'cood':num});
        }
      }
      console.log("随机数",numbers)
      this.setData({
        code:numbers
      })
      this.createcode()
    },
    createcode(){
      let nulist = this.data.code
      let golist = this.data.product
      let goolist = this.data.pro_list = []
      for(let i=0;i<nulist.length;i++){
        for(let j=0;j<golist.length;j++){
          if(golist[j].product_id == nulist[i].cood)
          {
            goolist.push({
            'product_id':golist[j].product_id,
            'product_name':golist[j].product_name,
            'imgurl':golist[j].imgurl,
            'price':golist[j].price,
            'sold':golist[j].sold
          })
            if(goolist.length<=10){
              this.setData({
                pro_list:goolist
              })
            }else{
              return false
            }
          }
        }
      }
    },
    shuaxin(){
      var that = this;
      that.setData({
        loadingHidden: false
       });
       setTimeout(function(){
        that.setData({
          loadingHidden: true
        });
        wx.showToast({
          title: '刷新成功',
          icon:'success',
          duration:1000
        })
        wx.pageScrollTo({
          scrollTop: 400,
          duration:300
        })
        that.createshu()
       }, 1500);

    },
    showModal(e){
      let {type}=e.currentTarget.dataset,va='';
      if(type=='s1'){
        va="s1";
      }
      this.setData({
        [va]:true
      })
    },
    goTop: function (e) {
      if (wx.pageScrollTo) {
        wx.pageScrollTo({
          scrollTop: 0,
          duration:300
        })
      } else {
        wx.showModal({
          title: '提示',
          content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
        })
      }
    },
    onPageScroll: function (e) {
      if (e.scrollTop > 200) {
        this.setData({
          no_scroll: true
        });
      } else {
        this.setData({
          no_scroll: false
        });
      }
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {
 
    },
 
    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
 
    },
 
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {
 
    },
 
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {
 
    },
 
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
 
    },
 
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {
 
    },
 
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {
 
    }
})