// pages/ceshi/ceshi.js
const db = wx.cloud.database()
var app = getApp()
app.globalData.aid
app.globalData.cid
Page({
  /**
   * 页面的初始数据
   */
  data: {
    goods:[],
    leftname:[],
    bid:[],
    hight:null,
    hight1:null,
    choose:true,
    chickid:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let that = this
    /*db.collection('fenlei2').where({fenlei_id:db.command.eq("h")}).get({
      success:res=> {
        console.log('右边获取成功',res)
        that.setData({
          goods:res.data
        })
      },
      catch:res=> {
        console.log('右边获取失败！',res)
      }
    }),*/
    db.collection('fenlei2').where({leiid:db.command.eq(0)}).get({
      success:res=> {
        console.log('左边获取成功',res)
        that.setData({
          leftname:res.data
        })
      },
      catch:res=> {
        console.log('左边获取失败！',res)
      }
    })
    var winHeight = wx.getSystemInfoSync().windowHeight //设置变量存放屏幕高度值
        console.log(winHeight) //打印屏幕高度
        this.setData({
            hight:winHeight //传递值
        })
    var winHeight1 = wx.getSystemInfoSync().windowHeight //设置变量存放屏幕高度值
      console.log(winHeight1) //打印屏幕高度
      this.setData({
          hight1:winHeight-50 //传递值
      })
  },
  tap:function(e){
    let that = this
    var lei_id=e.currentTarget.dataset.id;
    app.globalData.aid = e.currentTarget.dataset.id
    var bid=app.globalData.aid
    db.collection('fenlei2').where({fenlei_id:db.command.eq(bid)}).get({
      success:res=> {
        console.log('右边获取成功',res)
        that.setData({
          goods:res.data,
        })
      },
      catch:res=> {
        console.log('右边获取失败！',res)
      }
    })
    that.setData({
      choose:false,
      clickid:e.currentTarget.id
    })
  },
  goto:function(even){
    var mid=even.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/fenlei1/fenlei1?id='+mid,
    })
    app.globalData.cid=even.currentTarget.dataset.id
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})