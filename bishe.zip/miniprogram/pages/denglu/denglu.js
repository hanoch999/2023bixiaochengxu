var app = getApp()
app.globalData.userOpenId
Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUseGetUserProfile: false,
    useropenid:''
  },
  onLoad() {
    if (wx.getUserProfile) {
      this.setData({
        canIUseGetUserProfile: true
      })
    }
    console.log(app.globalData.userOpenId)
  },
  login: function(){
    var that = this;
    wx.showModal({//用户授权弹窗
      title: '确定登录',
      content: '提示',
      success(res) {
        console.log(res)
        //如果用户点击了确定按钮
        if (res.confirm) {
          wx.getUserProfile({
            desc: '获取你的昵称、头像、地区及性别',
            success: res => {
              console.log(res.userInfo)//控制台输出结果
              console.log("获取成功");
              that.setData({
                userInfo:res.userInfo,
                hasUserInfo: true
              })
              wx.setStorageSync('userinfo', res.userInfo)
              wx.login({
                //获取code
                success: function (res) {
                  var code = res.code; //返回code
                  console.log(code);
                  var appId = 'wx1962d03173232e99';//微信小程序AppID
                  var secret = '9eb76185d3a564f6bf16f5a8d9f0085d';//可在微信公众平台设置扫描二维码获取
                  wx.request({
                    url: 'https://api.weixin.qq.com/sns/jscode2session?appid='+appId+'&secret='+secret+'&js_code='+code+'&grant_type=authorization_code',
                    data: {},
                    header: { 
                      'content-type': 'json'
                    },   
                    success: function (res) {
                      var openid = res.data.openid //返回openid
                      console.log('用户openid',openid)//控制台打印openid
                      app.globalData.userOpenId = openid;
                      wx.setStorageSync('userid', openid)
                      that.setData({
                        useropenid:openid
                      })
                    }
                  })
                }
              })
              let dataTime
              let yy = new Date().getFullYear()
              let mm = new Date().getMonth()+1
              let dd = new Date().getDate()
              let hh = new Date().getHours()
              let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
                new Date().getMinutes()
              let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
                new Date().getSeconds()
                dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`;
              console.log(dataTime)
              wx.cloud.database().collection('user').add({
                data:{
                  name:that.data.userInfo.nickName,
                  imgurl:that.data.userInfo.avatarUrl,
                  crearetime:dataTime
                }

              })
            },
            fail: res => {
              console.log(res)
              //拒绝授权
              wx.showToast({
                title: '登录失败',
                icon: 'error',
                duration: 2000
              });
              return;
            }
          });
        } else if (res.cancel) {
          //如果用户点击了取消按钮
          console.log(3);
          wx.showToast({
            title: '登录失败',
            icon: 'error',
            duration: 2000
          });
          return;
        }
      }
    })
  }
  ,
  back(){
    let pages = getCurrentPages(); //页面栈
    let beforePage = pages[pages.length - 2];
    console.log(beforePage.route)
    wx.navigateBack({
      delta: 1, //返回的页面数，如果 delta 大于现有页面数，则返回到首页。
       success: function () {
        if (beforePage.route == 'pages/commodity/mySupply') {
          beforePage.onload()
           console.log('登录页面的id',userid)
         }
       }
     })

    // wx.switchTab({});    //tabBar页面的跳转
    /*wx.navigateTo({       //非tabBar页面的跳转
      url: '/' + beforePage.route,
      success: function () {
        if (beforePage.route == 'pages/commodity/mySupply') {
          beforePage.syncPageData()
        }
      },
      fail: (err) => {
        console.log(err)
      }
    })*/
  },
  getUserProfile(e) {
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
})

