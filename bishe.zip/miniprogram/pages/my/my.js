// pages/my/my.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    img:'cloud://huanjing1-4gxaab48492dde9e.6875-huanjing1-4gxaab48492dde9e-1305410126/图片/微信图片_20200920132100.jpg',
    username:'登录/注册   >',
    denglu:false
  },
  diorder(){
    wx.navigateTo({
      url: '../myorder/myorders',
    })
  },
  daifukuan(){
    wx.navigateTo({
      url: '../myorder/myorders?currentTab='+'1',
    })
  },
  daifahuo(){
    wx.navigateTo({
      url: '../myorder/myorders?currentTab='+'2',
    })
  },
  goodhistory(){
    wx.navigateTo({
      url: '../goodhistory/goodhistory',
    })
  },
  shoucang(){
    wx.navigateTo({
      url: '../shoucang/shoucang',
    })
  },
  daishouhuo(){
    wx.navigateTo({
      url: '../myorder/myorders?currentTab='+'3',
    })
  },
  daipin(){
    wx.navigateTo({
      url: '../myorder/myorders?currentTab='+'4',
    })
  },
  shanggoods(){
    wx.navigateTo({
      url: '../shanggoods/shanggoods',
    })
  },
  yijian(){
    wx.navigateTo({
      url: '../yijian/yijian',
    })
  },
  shangorder(){
    wx.navigateTo({
      url: '../shangorder/shangorder',
    })
  },
  mywenzhen(){
    wx.navigateTo({
      url: '../mywenzhen/mywenzhen',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(wx.getStorageSync('userinfo'))
    console.log(wx.getStorageSync('userid'))
    if(wx.getStorageSync('userinfo')==''){
      this.setData({
        denglu:true
      })
    }else(      
      this.setData({
      denglu:false
    }))
    this.setData({
      img:wx.getStorageSync('userinfo').avatarUrl,
      username:wx.getStorageSync('userinfo').nickName
    })
  },
  todeng(){
    wx.navigateTo({
      url: '../denglu/denglu',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide(){

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  dizhi(){
    wx.navigateTo({
      url: '../choose/choose',
    })
  }
})