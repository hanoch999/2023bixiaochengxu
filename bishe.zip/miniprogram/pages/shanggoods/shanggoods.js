// pages/shanggoods/shanggoods.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    fenlei1model:false,
    fenlei2model:false,
    fenlei1:[],
    fenlei2:[],
    left:[],
    middle:[],
    right:[],
    fenlei1name:'选择一级商品类别',
    fenlei2name:'选择二级商品类别',
    fenlei1id:'',
    fenlei2id:'',
    goods:[],
    changegood:[],
    changemodel:false,
    changename:'',
    changeprice:'',
    changedetail:'',
    changedetail1:'',
    changedetail2:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    db.collection('fenlei2').where({leiid:db.command.eq(0)}).get({
      success:res=> {
        this.setData({
          fenlei1:res.data
        })
      },
      catch:res=> {
        console.log('左边获取失败！',res)
      }
    })  
  },
  fenlei1(){
    this.setData({
      fenlei1model:true
    })
  },
  fenlei11(){
    this.setData({
      fenlei1model:false
    })
  },
  fenlei2(){
    this.setData({
      fenlei2model:true
    })
    db.collection('fenlei2').where({'fenlei_id':this.data.fenlei1id}).get().then(res=>{
      this.setData({
        fenlei2:res.data
      })
    })
  },
  fenlei21(){
    this.setData({
      fenlei2model:false
    })
  },
  choose:function(e){
    let fenlei12= this.data.fenlei1
    let choose1 = e.currentTarget.dataset.index
    let name= ''
    for(let i=0;i<fenlei12.length;i++){
      if(choose1==fenlei12[i].fenlei_id){
        name=fenlei12[i].leftname
        this.setData({
          fenlei1name:name,
          fenlei1id:choose1
        })
      }
    }
    this.fenlei11()
  },
  choose1:function(e){
    let fenlei22= this.data.fenlei2
    let choose2 = e.currentTarget.dataset.fen2
    let name1= ''
    for(let i=0;i<fenlei22.length;i++){
      if(choose2==fenlei22[i].leiid){
        name1=fenlei22[i].rightname
        this.setData({
          fenlei2name:name1,
          fenlei2id:choose2
        })
      }
    }
    this.fenlei21()
    this.goods()
  },
  goods(){
    let leiid = this.data.fenlei2id
    db.collection('goodss').where({'leiid':leiid}).get().then(res=>{
      this.setData({
        goods:res.data
      })
    })
  },
  delete:function(e){
    let productid = e.currentTarget.dataset.poid
    wx.showModal({
      title: '确定要删除此商品吗？',
      content: '',
      complete: (res) => {
        if (res.confirm) {
          db.collection('goodss').where({'_id':productid}).remove().then(res=>{
            console.log(res.data)
          })
        }
      }
    })
    this.onLoad()
  },
  changes(){
    this.setData({
      changemodel:false
    })
    this.onLoad()
  },
  change:function(e){
    let productid = e.currentTarget.dataset.pooid
    let goodd = this.data.goods
    let change=[]
    for(let i=0;i<goodd.length;i++){
      if(productid==goodd[i]._id){
        change.push(goodd[i])
      }
    }
    this.setData({
      changegood:change,
      changemodel:true
    })

  },
  name:function(e){
    this.setData({
      changename:e.detail.value
    })
    console.log(this.data.changename)
  },
  price:function(e){
    this.setData({
      changeprice:e.detail.value
    })
  },
  jieshao1:function(e){
    this.setData({
      changedetail:e.detail.value
    })
  },
  jieshao2:function(e){
    this.setData({
      changedetail1:e.detail.value
    })
  },
  jieshao3:function(e){
    this.setData({
      changedetail2:e.detail.value
    })
  },
  changegood:function(e){
    let goodid = e.currentTarget.dataset.goodid
    console.log(goodid)
    if(this.data.changename==''){

    }else{
      console.log('修改后的内容',this.data.changename)
      db.collection('goodss').where({'_id':goodid}).update({
          data:{
            product_name:this.data.changename
          }
      })
      wx.showToast({
        title: '修改成功',
        icon:'success',
        duration:1500
      })
      this.changes()
    }
    if(this.data.changeprice==''){

    }else{
      console.log('修改后的价格',this.data.changeprice)
      db.collection('goodss').where({'_id':goodid}).update({
          data:{
            price:this.data.changeprice
          }
      })
      wx.showToast({
        title: '修改成功',
        icon:'success',
        duration:1500
      })
      this.changes()
    }
    if(this.data.changedetail==''){

    }else{
      console.log('修改后的价格',this.data.changedetail)
      db.collection('goodss').where({'_id':goodid}).update({
          data:{
            detail:this.data.changedetail
          }
      })
      wx.showToast({
        title: '修改成功',
        icon:'success',
        duration:1500
      })
      this.changes()
    }
    if(this.data.changedetail1==''){

    }else{
      console.log('修改后的价格',this.data.changedetail1)
      db.collection('goodss').where({'_id':goodid}).update({
          data:{
            detail1:this.data.changedetail1
          }
      })
      wx.showToast({
        title: '修改成功',
        icon:'success',
        duration:1500
      })
      this.changes()
    }
    if(this.data.changedetail2==''){

    }else{
      console.log('修改后的价格',this.data.changedetail2)
      db.collection('goodss').where({'_id':goodid}).update({
          data:{
            detail2:this.data.changedetail2
          }
      })
      wx.showToast({
        title: '修改成功',
        icon:'success',
        duration:1500
      })
      this.changes()
    }
    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})