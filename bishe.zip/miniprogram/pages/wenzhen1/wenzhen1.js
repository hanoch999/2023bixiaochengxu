// pages/wenzhen1/wenzhen1.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    wenid:'',
    msgbox:[],
    info:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let that = this
    var mid =options.wenid 
    console.log(options.wenid)
    that.setData({
      wenid:mid
    })
    db.collection('wenzhen').where({'_id':mid}).get().then(res => {
      this.setData({
        info:res.data[0],
        msgbox:res.data[0].msgbox
      })
      console.log(res.data[0])
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})