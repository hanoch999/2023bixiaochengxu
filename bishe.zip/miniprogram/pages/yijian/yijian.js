// pages/yijian/yijian.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isjiantou:true,   //箭头切换
    selectcontent:[
      {id:1,name:"智能问诊"},
      {id:2,name:"商城意见"},
      {id:3,name:"其他"},
    ],
    value:undefined,   //选中的值
    valueid:undefined,  //选中的id
    neirong:''
  },
  changejiantou(){
    this.setData({
      isjiantou:!this.data.isjiantou
    })
  },
  input(e){
    console.log(e.detail.value)
    this.setData({
      neirong:e.detail.value
    })
  },
  // 选择数据后回显
  changecontent(e){
    this.setData({
      value:e.currentTarget.dataset.datavalue.name,
      valueid:e.currentTarget.dataset.datavalue.id,
      isjiantou:true
    })
  },
  tijoao(){
    let dataTime
          let yy = new Date().getFullYear()
          let mm = new Date().getMonth()+1
          let dd = new Date().getDate()
          let hh = new Date().getHours()
          let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
            new Date().getMinutes()
          let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
            new Date().getSeconds()
            dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`;
    wx.cloud.database().collection('yijian').add({
      data:{
        type:this.data.value,
        time:dataTime,
        nierong:this.data.neirong
      }
    })
    wx.showToast({
      title: '提交成功',
      icon:'success',
      duration:1500
    })
    this.onLoad()
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})