// pages/gouwuche/gouwuche.js
const app=getApp()
const goid = app.globalData.goodid
/*app.globalData.userOpenId*/
const db = wx.cloud.database()
const _ = db.command 
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isSelectAll: false,
    isshow:'true',
    list:[],
    good:[],
    total:0,
    tocount:0,
    hight:null,
    showview:true,
    cart:[],
    shanshow:false,
    totalArr: [],
    address:"",
    isAllChecked: false,
    totalPrice:0,
    denglu:false,
    userid:""
  },
  onLoad: function (options) {
    let userid = wx.getStorageSync('userid')
    console.log(wx.getStorageSync('userid'))
    if(userid==''){
      this.setData({
        denglu:true
      })
    }else{
      this.setData({
        denglu:false
      })
    }
      var winHeight = wx.getSystemInfoSync().windowHeight //设置变量存放屏幕高度值
      console.log(winHeight) //打印屏幕高度
      this.setData({
          hight:winHeight-105,//传递值,
      })      
  },
  denglu(){
    wx.navigateTo({
      url: '../denglu/denglu',
    })
  },
  shanchu:function(e){
    var that = this
    var golist = that.data.cart
    for(let i=0;i<golist.length;i++ ){
        golist[i].shanimg = true
    }
    that.setData({
      cart:golist,
      shanshow:true
    })
  },
  tuishan:function(e){
    var that = this
    var golist = that.data.cart
    for(let i=0;i<golist.length;i++ ){
        golist[i].shanimg = false
    }
    that.setData({
      cart:golist,
      shanshow:false
    })
  },
  delete:function(e){
    var that = this
    var golist = that.data.cart
    const pdid = e.currentTarget.dataset.shan
    golist.splice(pdid,1);//删除
    that.setData({
      cart: golist
    })
    wx.showToast({
      title: '删除成功',
      icon:'success',
      duration:2000
    })
    wx.cloud.database().collection('cart').doc(pdid).remove().then(res=>{
      console.log('删除成功',res)
    })
  },
  img:function(e){
    var goid=e.currentTarget.dataset.inn
    console.log(goid)
    wx.navigateTo({
      url: '/pages/good/good?id='+goid,
    })
    app.globalData.goodid=e.currentTarget.dataset.inn
    
  },
  choose_num:function(e){
    var that = this
    const cid = e.currentTarget.dataset.index
    var golist = that.data.cart
    for(let i=0;i<golist.length;i++ ){
      if(cid == golist[i]._id){
          golist[i].isshow=false
        }
      }
    that.setData({
      cart:golist
    })
  },
  isclose:function(e){
    var that = this
    const cid = e.currentTarget.dataset.index
    var golist = that.data.cart
    for(let i=0;i<golist.length;i++ ){
      if(cid === golist[i]._id){
          golist[i].isshow = true
      }
    }
    that.setData({
      cart:golist
    })
  },
  handleTap:function(e){
    let that = this
    const itemdata = e.currentTarget.dataset
    let carrt = that.data.cart
    let totalprice = Number(that.data.total)
    let totalcount = Number(that.data.tocount)
    let itemindex = itemdata.index
    let itemprice = itemdata.price
    let itemselect = itemdata.checked
    let itemcount = itemdata.count
    let itemtotalprice = itemprice * itemcount
    let itemchangechecked = `carrt[${itemindex}].checked`
    if(itemselect=false){
      totalprice -= itemtotalprice;
      totalcount -= itemcount
    } else {
      totalprice += itemtotalprice;
      totalcount += itemcount
    }
    totalprice = totalprice.toFixed(2)
    that.setData({
      itemselect:!itemselect,
      total:totalprice,
      tocount:totalcount
    })
    wx.setStorageSync('cart', {
      total:totalprice,
      tocount:totalcount
    })

    /*that.data.cart[cindex].checked = !that.data.cart[cindex].checked;
    this.setData({  //更新一下改变后的数据
      cart: that.data.cart
    })
    console.log(chooseid)*/
  },

  allChecked(e) {
    let jiesuan= []
    if (this.data.isAllChecked) {
        let goodsList = JSON.parse(JSON.stringify(this.data.cart))
        goodsList.forEach(item => item.checked = false)  //这里是赋值
        this.setData({
          isAllChecked: false,
          cart: goodsList,
          tocount:0
        })
        this.computedTotalPrice()
    } else {
        let goodsList = JSON.parse(JSON.stringify(this.data.cart))
        goodsList.forEach(item => {
          item.checked = true
          for(let i=0;i<goodsList.length/goodsList.length;i++){
            if(goodsList[i].checked=true){[
              jiesuan.push({
                cart_num:item.cart_num,
                imgurl:item.imgurl,
                price:item.price,
                product_id:item.product_id,
                product_name:item.product_name
              })
            ]}
          }
        })  //这里是赋值
        wx.setStorageSync('carts', jiesuan)
        this.setData({
            isAllChecked: true,
            cart: goodsList,
            tocount:goodsList.length
        })
        this.computedTotalPrice()
        wx.setStorageSync('cart', {
          tocount:goodsList.length,
          total:this.data.totalPrice
        }
      )
    }
    
  },
  computedTotalPrice() {
    let totalPrice = this.data.cart.reduce((total, item) => {
        if (item.checked) {
            return total + item.cart_num * item.price
        } else {
            return total
        }
    }, 0)
    this.setData({
        totalPrice: totalPrice.toFixed(2)
    })
},
  changeCound(e) {
    let that = this
    let checkedArr = e.detail.value
    let jiesuan = []
    if (checkedArr.length == that.data.cart.length) {
        let goodsList = JSON.parse(JSON.stringify(that.data.cart))
        goodsList.forEach(item => item.checked = true)
        that.setData({
            isAllChecked: true,
            goods: goodsList,
            tocount:checkedArr.length
        })
    } else {
        let goodsList = JSON.parse(JSON.stringify(that.data.cart))
        /*let values = e.detail.value
        for(let i=0;i<goodsList.length;i++){{
          goodsList[i].checked = false
            if(values==goodsList[i]._id){
              goodsList[i].checked = true
              console.log(goodsList[i])
            }else{
              goodsList[i].checked = false
            } 
          }}*/
          goodsList.forEach(item => {
            if (checkedArr.includes(item._id)) {
                item.checked = true
                jiesuan.push({
                  cart_num:item.cart_num,
                  imgurl:item.imgurl,
                  price:item.price,
                  product_id:item.product_id,
                  product_name:item.product_name
                })
            } else {
                item.checked = false
            }
            that.setData({
              isAllChecked: false,
              cart: goodsList,
              tocount:checkedArr.length
          })
          that.computedTotalPrice()
            wx.setStorageSync('carts', jiesuan)
            wx.setStorageSync('cart', {
              tocount:checkedArr.length,
              total:this.data.totalPrice
            })
        })
    }
  },
  jiesuan(){
    if(this.data.tocount == 0){
      wx.showToast({
        title: '当前没有商品',
        icon:'error',
        duration:1000
      })
    }else{
      wx.navigateTo({
        url: '../wait/wait',
      })
    }
    wx.setStorageSync('address1', 
      this.data.address
    )

  },
  jianshao:function(e){
    console.log(e.currentTarget.dataset.num)
    let gid = e.currentTarget.dataset.id
    let nums = e.currentTarget.dataset.num
    let cartlis = this.data.cart
    let newnum = ''
    nums--
    if(nums==1){
      wx.showToast({
        title: '商品不可以在减少了哦',
        icon:'error',
        duration:1500
      })
    }
    console.log(nums)
    db.collection('cart').where({'_id':gid}).update({
      data:{
        cart_num:nums
      }
    })
    this.onShow()
  },
  zengjia:function(e){
    console.log(e.currentTarget.dataset.num)
    let gid = e.currentTarget.dataset.id
    let nums = e.currentTarget.dataset.num
    let cartlis = this.data.cart
    let newnum = ''
    nums++
    if(nums==1){
      wx.showToast({
        title: '商品不可以在减少了哦',
        icon:'error',
        duration:1500
      })
    }
    console.log(nums)
    db.collection('cart').where({'_id':gid}).update({
      data:{
        cart_num:nums
      }
    })
    this.onShow()
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow:function(){
    this.onLoad()
    wx.cloud.database().collection("cart").get().then(res=>{
      console.log(res.data)
      this.setData({
        cart:res.data
      })
    })
    this.setData({
      address:wx.getStorageSync('chooseadd')
    })
    var that = this
    db.collection('address').where(_.or([
      {_openid:that.data.userid},{defalt:true}
    ])).get().then(res=>{
      console.log(res.data)
      that.setData({
        address:res.data
      })
      console.log(that.data.address)
    })
  },
  addresschange(){
    wx.navigateTo({
      url: '../choose1/choose1',
    })
    let tocount = 0,
    total = 0
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})