// pages/good/good.js
const db = wx.cloud.database()
var app = getApp()
app.globalData.goodid
app.globalData.shangnum
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    good2:[],
    xuan:false,
    num1:[],
    toprice:[],
    shoucang1:[],
    shouimg:[],
    shouimg1:	'https://6875-huanjing1-4gxaab48492dde9e-1305410126.tcb.qcloud.la/ui/%E7%88%B1%E5%BF%83.png?sign=662bd3282f1784520b9ba7578068a28f&t=1679558210',
    shouimg2:	'cloud://huanjing1-4gxaab48492dde9e.6875-huanjing1-4gxaab48492dde9e-1305410126/ui/爱心 (2).png',
    shoutxt:'收藏',
    shoutxt1:'已收藏',
    enshrine: true, //收藏
    carnum:1,
    minusStatus: 'disabled',
    currentTab:0,
    cart1:[],
    goodhistory:[],
    imgg:'',
    pricee:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let that = this
    var good1 = app.globalData.goodid
    let goodd = []
    db.collection('goodss').where({product_id:db.command.eq(good1)}).get({
      success:res=> {
        goodd.push(res.data[0])
        that.setData({
          good2:res.data,
          toprice:res.data[0].price,
          carnum:res.data[0].cart_num,
          imgg:res.data[0].imgurl,
          pricee:res.data[0].price
        })
      },
      catch:res=> {
        console.log('商品详细信息获取失败！',res)
      }
    }),
    db.collection('cart').get({
      success:res=> {
        console.log('购物车信息获取成功',res)
        that.setData({
          cart1:res.data,
        })
      },
      catch:res=> {
        console.log('商品详细信息获取失败！',res)
      }
    })
    db.collection('shoucang').where({product_id:db.command.eq(good1)}).get({
      success:res=> {
        console.log(res.data)
        that.setData({
          enshrine: res.data[0].enshrine
        })
      },
      catch:res=> {
        console.log('商品详细信息获取失败！',res)
      }
    })
  },
  isenshrine:function(e) {
  let that = this
  var shoulist =[]
  db.collection('shoucang').add({
      data:{
        product_name:this.data.good2[0].product_name,
        product_id:this.data.good2[0].product_id,
        imgurl:this.data.good2[0].imgurl,
        enshrine: false,
        price:this.data.good2[0].price,
        checked:false
      }
    })
    wx.showToast({
      title: '收藏成功',
      icon:'success',
      duration:1500
    })
  that.setData({
    enshrine:false
  })
  },
  quxiaoshou:function(e) {
    let that = this
    var shoulist =[]
    db.collection('shoucang').where({product_id:app.globalData.goodid}).remove().then(res =>{
      console.log(res.data)
      })
      wx.showToast({
        title: '取消收藏',
        icon:'error',
        duration:1500
      })
    that.setData({
      enshrine:true
    })
    },
  shouy:function(){
    var good1 = app.globalData.goodid
    console.log("收藏的商品",good1)
    let that = this
    if('shoucang1==0'){
      db.collection("goodss").doc("good1").update({
        data:{//更改的字段
          shoucang:123
        }
      }).then(res=>{
       console.log("修改成功",res);
      })
    }
    else if('shoucang1==1'){
      that.setData({
        shoucang:0
      })
    }
  },
  previewImage: function (e) {
    var imgUrl = this.data.good2[0].imgurl;
    wx.previewImage({
      urls: [imgUrl], // 需要预览的图片http链接列表
      current: '', // 当前显示图片的http链接
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
  },
  /*数量修改*/
  jian:function(e){
    var that = this
    let xuan = that.data.carnum
    if(xuan>=2)
    {
      xuan--
    }
    var minusStatus = xuan <= 2 ? 'disabled' : 'normal';
    that.setData({
      carnum:xuan,
      minusStatus: minusStatus ,
    })
    if(xuan==1)
    wx.showToast({
      title: '请至少选择一件哦！',
      duration:1500,
      icon:'none'
    })
  },
  jia:function(e){
    var that = this
    let xuan = that.data.carnum
    xuan++
    that.setData({
      carnum:xuan,
      isdisabled:true,
    })
  },
  bindManual: function(e) { 
    var that = this
    var num = e.detail.value; 
    // 将数值与状态写回 
    that.setData({ 
      carnum: num 
    }); 
  } ,
  gouwu:function(){
    wx.switchTab({
      url: '../gouwuche/gouwuche',
    })
  },
  clickme:function(){
    this.showModal();
  },
  
  //显示对话框
   showModal: function () {
     // 显示遮罩层
     var animation = wx.createAnimation({
       duration: 100,
       timingFunction: "linear",
       delay: 0
     })
     this.animation = animation
     animation.translateY(300).step()
     this.setData({
       animationData: animation.export(),
       showModalStatus: true
     })
     setTimeout(function () {
       animation.translateY(0).step()
       this.setData({
         animationData: animation.export()
       })
     }.bind(this), 200)
   },
   //隐藏对话框
   hideModal: function () {
     // 隐藏遮罩层
     var animation = wx.createAnimation({
       duration: 200,
       timingFunction: "linear",
       delay: 0
     })
     this.animation = animation
     animation.translateY(300).step()
     this.setData({
       animationData: animation.export(),
     })
     setTimeout(function () {
       animation.translateY(0).step()
       this.setData({
         animationData: animation.export(),
         showModalStatus: false
       })
     }.bind(this), 200)
   },
  /**
   * 生命周期函数--监听页面隐藏
   */
  swiperTab:function( e ){
    var that=this;
    that.setData({
     currentTab:e.detail.current
    });
   },
   //点击切换
   clickTab: function( e ) { 
    var that = this; 
    if( this.data.currentTab === e.target.dataset.current ) { 
     return false; 
    } else { 
     that.setData( { 
      currentTab: e.target.dataset.current 
     }) 
    } 
   } ,
   /*加入购物车 */
   addCar: function (e) {
    let that = this
    let pdid = that.data.good2[0].product_id;
    let ccnum = that.data.carnum
    let pdname = that.data.good2[0].product_name
    let pdimg = that.data.good2[0].imgurl
    let price = that.data.good2[0].price
    let cart1 =that.data.cart1
    let flag = true
    if(cart1){
      for(let i=0;i<cart1.length;i++)
    {
      if(pdid===cart1[i].product_id){
        cart1[i].cart_num = cart1[i].cart_num+ccnum
          console.log('购物车已经有此商品',cart1[i].cart_num)
          let newnum = cart1[i].cart_num
          let newnumid= cart1[i].product_id
          flag = false
          db.collection('cart').where({product_id:newnumid}).update({
            data:{
              cart_num:newnum
            }
          })
      }
    }
    if(flag){
        console.log('none')
        db.collection('cart').add({
          data:{
            product_name:pdname,
            imgurl:pdimg,
            product_id:pdid,
            cart_num:ccnum,
            isshow:true,
            price:price,
            shanimg:false,
            checked:false
          },
          success:function(res){
            console.log(res)   
            
          },
          fail:function(res){
            console.log(res)
          }
        })
        wx.showToast({
          title: '添加成功',
         })
      }
    }
    /*if(cart1.indexOf(pdid) > -1){
      console.log('没有这个商品',cart1.indexOf(pdid))

      } else if(cart1.indexOf(pdid) === -1){
      console.log(cart1.indexOf(pdid))
      for(let i =0;i<cart1.length;i++){
        if(pdid==cart1[i].product_id){
          cart1[i].cart_num = cart1[i].cart_num+ccnum
          console.log('购物车已经有此商品',cart1[i].cart_num)
          let newnum = cart1[i].cart_num
          let newnumid= cart1[i].product_id
          db.collection('cart').where({product_id:newnumid}).update({
            data:{
              cart_num:newnum
            }
          })
        }
      }
    }*/

    that.hideModal()
  },
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})