// pages/fenlei1/fenlei1.js
const db = wx.cloud.database()
var app = getApp()
app.globalData.cid
app.globalData.goodid
Page({

  /**
   * 页面的初始数据
   */
  data: {
    lei_id:[],
    list:[],
    currentTab:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let that = this
    var mid =options.id 
    console.log(options.id)
    that.setData({
      lei_id:mid
    })
    console.log("小分类id:",mid)
    let scc = app.globalData.cid
    console.log(app.globalData.cid)
    db.collection('goodss').where({leiid:db.command.eq(scc)}).get({
      success:res=> {
        console.log('商品获取成功',res)
        that.setData({
          list:res.data,
        })
      },
      catch:res=> {
        console.log('商品获取失败！',res)
      }
    })
  },
  paixu1:function(e){
    let that = this
    var scc = app.globalData.cid
    console.log(app.globalData.cid)
    db.collection('goodss').where({leiid:db.command.eq(scc)}).get({
      success:res=> {
        console.log('商品获取成功',res)
        that.setData({
          list:res.data,
        })
      },
      catch:res=> {
        console.log('商品获取失败！',res)
      }
    })
    if( that.data.currentTab === e.target.dataset.current ) { 
      return false; 
     } else { 
      that.setData( { 
       currentTab: e.target.dataset.current 
      }) 
     } 
  },
  detail:function(even){
    var zid=even.currentTarget.dataset.id
    console.log("商品id：",zid)
    wx.navigateTo({
      url: '/pages/good/good?id='+zid,
    })
    app.globalData.goodid=even.currentTarget.dataset.id
    console.log("商品全局变量：",app.globalData.goodid)
  },
  paixu2:function(e){
    var scc = app.globalData.cid
    console.log(app.globalData.cid)
    wx.cloud.database().collection("goodss").orderBy("price","asc").where({leiid:db.command.eq(scc)}).get().then(res=>{
      console.log("升序成功",res);
      this.setData({
        list:res.data
      })
    })
    .catch(err=>{
      console.log("升序失败",err);
    })
    if( this.data.currentTab === e.target.dataset.current ) { 
      return false; 
     } else { 
      this.setData( { 
       currentTab: e.target.dataset.current 
      }) 
     } 
  },
  paixu3:function(e){
    var scc = app.globalData.cid
    console.log(app.globalData.cid)
    wx.cloud.database().collection("goodss").orderBy("price","desc").where({leiid:db.command.eq(scc)}).get().then(res=>{
      console.log("降序成功",res);
      this.setData({
        list:res.data
      })
    })
    .catch(err=>{
      console.log("降序失败",err);
    })
    if( this.data.currentTab === e.target.dataset.current ) { 
      return false; 
     } else { 
      this.setData( { 
       currentTab: e.target.dataset.current 
      }) 
     } 
  },
  search(){
    wx.navigateTo({
      url: '../search/search',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})