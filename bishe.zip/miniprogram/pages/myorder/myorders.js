// pages/myorder/myorders.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    order1:{},//待付款
    order2:[],//待发货
    order3:[],//待收货
    order4:[],//待评价
    order5:[],//
    orders:[],//总订单
    currentTab:0,
    hight:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    var winHeight = wx.getSystemInfoSync().windowHeight //设置变量存放屏幕高度值
    this.setData({
        hight:winHeight-80//传递值
    })
    this.setData({
      currentTab:options.currentTab
    })
    db.collection('dingdan').orderBy('createtime','desc').get().then(res=>{
      this.setData({
        orders:res.data
      })
    })
    db.collection('dingdan').where({'label':'success'}).orderBy('createtime','desc').get().then(res=>{
      this.setData({
        order2:res.data
      })
    })
    db.collection('dingdan').where({'label':'cancel'}).orderBy('createtime','desc').get().then(res=>{
      this.setData({
        order1:res.data
      })
    }),
    db.collection('dingdan').where({'label':'send'}).orderBy('createtime','desc').get().then(res=>{
      this.setData({
        order3:res.data
      })
    })
  },
  swiperTab:function( e ){
    var that=this;
    that.setData({
     currentTab:e.detail.current
    });
   },
   //点击切换
   clickTab: function( e ) { 
    var that = this; 
    if( this.data.currentTab === e.target.dataset.current ) { 
     return false; 
    } else { 
     that.setData( { 
      currentTab: e.target.dataset.current 
     }) 
    } 
   },
   shouhuo:function(e){
     let orderid= e.currentTarget.dataset.orderid
     console.log(orderid)
     wx.showModal({
       title: '是否确认收货',
       content: '',
       complete: (res) => {
         if (res.cancel) {
           
         }
     
         if (res.confirm) {
           db.collection('dingdan').where({'orderid':orderid}).update({
             data:{
               label:'over'
             }
           })
           wx.navigateTo({
             url: '../myorder/myorders',
           })
         }
       }
     })
   },
   quxiao:function(e){
    let quid = e.currentTarget.dataset.quxiao
    wx.showModal({
      title: '是否取消订单',
      content: '',
      complete: (res) => {
        if (res.confirm) {
          db.collection('dingdan').where({'orderid':quid}).update({
            data:{
              label:'remove'
            }
          })
          wx.navigateTo({
            url: '../myorder/myorders',
          })
        }
      }
    })
   },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})