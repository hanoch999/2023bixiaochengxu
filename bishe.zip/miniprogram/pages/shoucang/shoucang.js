// pages/shoucang/shoucang.js
const db = wx.cloud.database()
var app = getApp()
app.globalData.cid
app.globalData.goodid
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goods:[],
    guanli:false,
    allchecked:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    db.collection('shoucang').get().then(res => {
      console.log(res.data)
      this.setData({
        goods:res.data
      })
    })
  },
  guanli(){
    this.setData({
      guanli:true
    })
  },
  wancheng(){
    this.setData({
      guanli:false
    })
  },
    delete:function(e){
      console.log(e.currentTarget.dataset.id)
      let goid = e.currentTarget.dataset.id
      db.collection('shoucang').where({product_id:goid}).remove().then(res =>{
        console.log(res)
        wx.showToast({
          title: '取消收藏成功',
          icon:'success',
          duration:1500
        })
      })
      this.setData({
        guanli:false
      })
      this.onLoad()
    },
    detail:function(even){
      var zid=even.currentTarget.dataset.id
      console.log("商品id：",zid)
      wx.navigateTo({
        url: '/pages/good/good?id='+zid,
      })
      app.globalData.goodid=even.currentTarget.dataset.id
      console.log("商品全局变量：",app.globalData.goodid)
    },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})