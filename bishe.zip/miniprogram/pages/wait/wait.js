// pages/wait/wait.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    totalcount:'',
    totalprice:'',
    address:[],
    goods:[],
    minute: '',
    second: '',
    color:['red'],
    showdetail:false,
    animationData: {},
    beizhu:'无备注',
    beizhumodle:false,
    max:150,
    currentWordNumber:0,
    place:'选填，请输入需要备注的信息',
    bei:null,
    zhifumodel:false,
    orderid:''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    wx.setNavigationBarTitle({
      title: '订单确认',
    })
    let that =this
    that.setData({
      totalcount: wx.getStorageSync('cart').tocount,
      totalprice:wx.getStorageSync('cart').total,
      address:wx.getStorageSync('address1'),
      goods:wx.getStorageSync('carts'),
      place:'选填，请输入需要备注的信息'
    })
    console.log(that.data.goods)
  },
  detail(){
    var that=this;
    that.setData({
      showdetail:true
    })
    var animation = wx.createAnimation({
      duration: 600,//动画的持续时间 默认400ms   数值越大，动画越慢   数值越小，动画越快
      timingFunction: 'ease',//动画的效果 默认值是linear
    })
    that.animation = animation 
    setTimeout(function(){
      that.fadeIn();//调用显示动画
    },200)   
  },

  hide: function () {
    var that=this; 
    var animation = wx.createAnimation({
      duration: 200,//动画的持续时间 默认400ms   数值越大，动画越慢   数值越小，动画越快
      timingFunction: 'ease',//动画的效果 默认值是linear
    })
    this.animation = animation
    that.fadeDown();//调用隐藏动画   
    setTimeout(function(){
      that.setData({
        showdetail:false
      })      
    },200)//先执行下滑动画，再隐藏模块
    
  },
  hidebeizhu: function () {
    var that=this; 
    var animation = wx.createAnimation({
      duration: 200,//动画的持续时间 默认400ms   数值越大，动画越慢   数值越小，动画越快
      timingFunction: 'ease',//动画的效果 默认值是linear
    })
    this.animation = animation
    that.fadeDown();//调用隐藏动画   
    setTimeout(function(){
      that.setData({
        beizhumodle:false
      })      
    },200)//先执行下滑动画，再隐藏模块
    
  },
  fadeIn:function(){
    this.animation.translateY(0).step()
    this.setData({
      animationData: this.animation.export()//动画实例的export方法导出动画数据传递给组件的animation属性
    })    
  },
  fadeDown:function(){
    this.animation.translateY(600).step()
    this.setData({
      animationData: this.animation.export(),  
    })
  },
  beizhu:function(){
    var that=this;
    that.setData({
      beizhumodle:true
    })
    var animation = wx.createAnimation({
      duration: 600,//动画的持续时间 默认400ms   数值越大，动画越慢   数值越小，动画越快
      timingFunction: 'ease',//动画的效果 默认值是linear
    })
    that.animation = animation 
    setTimeout(function(){
      that.fadeIn();//调用显示动画
    },200)   
  },
  inputs: function (e) {
    // 获取输入框的内容
    var value = e.detail.value;
    // 获取输入框内容的长度
    var len = parseInt(value.length);
    console.log(len)
    let bei = this.data.beizhu
    //最少字数限制
    if (len > this.data.max){
      wx.showToast({
        title: '已达字数上限',
        icon:'error',
        duration:1000
      })
        this.setData({
          texts: " ",
          textss: " ",
          num:''
        })
    }
    this.setData({
      currentWordNumber: len, //当前字数
      beizhu:value,
      bei:value
    });
    //最多字数限制
    if (len > this.data.max) return;
    // 当输入框内容的长度大于最大长度限制（max)时，终止setData()的执行
  },
  tijiao(){
    let prices = this.data.totalprice
    this.setData({
      zhifumodel:true
    })
  },
  zhifu(){
    let dataTime
    let yy = new Date().getFullYear()
    let mm = new Date().getMonth()+1
    let dd = new Date().getDate()
    let hh = new Date().getHours()
    let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
    new Date().getMinutes()
    let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
    new Date().getSeconds()
    dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`;
    let orderCode = '';
    // 6位随机数(加在时间戳后面)
    for (var i = 0; i < 6; i++)
    { 
      orderCode += Math.floor(Math.random() * 10);
    }
    // 时间戳(用来生成订单号)
    orderCode = 'D' + new Date().getTime() + orderCode;
    // 打印
    console.log(orderCode)
    db.collection('dingdan').add({
      data:{
        totalcount:this.data.totalcount,
        totalprice:this.data.totalprice,
        address:this.data.address,
        goodslist:this.data.goods,
        label:'success',
        createtime:dataTime,
        orderid:orderCode
      }
    })
    wx.navigateTo({
      url: '../dingdan/dingdan?orderid='+orderCode,
    })
  },
  quxiao(){
    let dataTime
    let yy = new Date().getFullYear()
    let mm = new Date().getMonth()+1
    let dd = new Date().getDate()
    let hh = new Date().getHours()
    let mf = new Date().getMinutes()<10?'0'+new Date().getMinutes():
    new Date().getMinutes()
    let ss = new Date().getSeconds()<10?'0'+new Date().getSeconds():
    new Date().getSeconds()
    dataTime = `${yy}-${mm}-${dd} ${hh}:${mf}:${ss}`;
    let orderCode = '';
    // 6位随机数(加在时间戳后面)
    for (var i = 0; i < 6; i++)
    { 
      orderCode += Math.floor(Math.random() * 10);
    }
    // 时间戳(用来生成订单号)
    orderCode = 'D' + new Date().getTime() + orderCode;
    // 打印
    console.log(orderCode)
    db.collection('dingdan').add({
      data:{
        totalcount:this.data.totalcount,
        totalprice:this.data.totalprice,
        address:this.data.address,
        goodslist:this.data.goods,
        label:'cancel',
        createtime:dataTime,
        orderid:orderCode
      }
    })
    wx.navigateTo({
      url: '../dingdan/dingdan?orderid='+orderCode,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})