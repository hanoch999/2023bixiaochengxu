// pages/shangorder/shangorder.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    order2:[],//待发货
    order3:[],//已发货
    order4:[],//待评价
    order5:[],//
    orders:[],//总订单
    currentTab:0,
    hight:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    wx.setNavigationBarTitle({
      title: '商家订单管理',
    })
    var winHeight = wx.getSystemInfoSync().windowHeight //设置变量存放屏幕高度值
    this.setData({
        hight:winHeight-80//传递值
    })
    db.collection('dingdan').orderBy('createtime','desc').get().then(res=>{
      this.setData({
        orders:res.data
      })
    })
    db.collection('dingdan').where({'label':'success'}).orderBy('createtime','desc').get().then(res=>{
      this.setData({
        order2:res.data
      })
    })
    db.collection('dingdan').where({'label':'send'}).orderBy('createtime','desc').get().then(res=>{
      this.setData({
        order3:res.data
      })
    })

  },
  swiperTab:function( e ){
    var that=this;
    that.setData({
     currentTab:e.detail.current
    });
   },
   //点击切换
   clickTab: function( e ) { 
    var that = this; 
    if( this.data.currentTab === e.target.dataset.current ) { 
     return false; 
    } else { 
     that.setData( { 
      currentTab: e.target.dataset.current 
     }) 
    } 
   },
   fahuo:function(e){
    let thisorder = this.data.orders
    let thisorder2 = this.data.order2 
    let orderid = e.currentTarget.dataset.orderid
    console.log(orderid)
    db.collection('dingdan').where({'orderid':orderid}).update({
      data:{
        label:'send'
      }
    }).then(res=>{
      console.log(res)
    })
    this.onLoad()
    wx.showToast({
      title: '发货成功',
      icon:'success',
      duration:1500
    })
    /*for(let i =0;i<thisorder2.length;i++){
      if(orderid==thisorder2[i].orderid){
        thisorder2[i].label='send'
        this.setData({
          orders:thisorder2
        })
      }
    }*/
   },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})