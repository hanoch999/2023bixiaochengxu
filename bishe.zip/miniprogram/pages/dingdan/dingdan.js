// pages/dingdan/dingdan.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orderid:null,
    totalcount:0,
    label:'',
    success:false,
    cancel:false,
    zhifu:false,
    address:[],
    goodslist:[],
    hight:null,
    totalprice:0,
    detail:true,
    more:false,
    time:[],
    navBarHeight: 0, //导航栏高度
    titleBottom: 0, //顶部距离
    title:'订单详情',
    hight:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    wx.setNavigationBarTitle({
      title: "订单详情",
    })
    this.getHeights()

    let orid = options.orderid
    var winHeight = wx.getSystemInfoSync().windowHeight //设置变量存放屏幕高度值
    console.log(winHeight) //打印屏幕高度
    this.setData({
        hight:winHeight-260//传递值
    })
    var winHeight1 = wx.getSystemInfoSync().windowHeight //设置变量存放屏幕高度值
    console.log(winHeight1) //打印屏幕高度
    this.setData({
        hight:winHeight-175//传递值
    })
    this.setData({
      orderid:orid
    })
    db.collection('dingdan').where({orderid:db.command.eq(this.data.orderid)}).get().then(res=>{
      console.log(res.data[0].goodslist)
      this.setData({
        totalcount:res.data[0].totalcount,
        label:res.data[0].label,
        address:res.data[0].address,
        goodslist:res.data[0].goodslist,
        totalprice:res.data[0].totalprice,
        time:res.data[0].createtime
      })
      if(res.data[0].label==='success'){
        this.setData({
          success:true
        })
      }else if(res.data[0].label==='cancel'){
        this.setData({
          cancel:true
        })
      }
    })
    
  },
  tomyy(){
    wx.switchTab({
      url: '../my/my',
    })
  },
  getHeights() {
    let that = this
    // 1.获取胶囊按钮的布局位置信息
    const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
    // 2.获取设备信息
    const systemInfo = wx.getSystemInfoSync();
    // 3.计算:计算公式：导航栏高度 = 状态栏高度 + 44。
    // 导航栏高度 = 状态栏高度 + 44
    this.setData({
      navBarHeight: systemInfo.statusBarHeight ,
      titleBottom: systemInfo.statusBarHeight
    })
    console.log(systemInfo.statusBarHeight)
  },
  //index.js文件 此处为点击事件逻辑
  textPaste() {
    let orderid = this.data.orderid
    wx.setClipboardData({
      data: orderid,
      success(res) {
        wx.getClipboardData({
          success(res) {
            wx.showToast({
              title: '复制成功',
            })
            console.log(res.data)
          }
        })
      }
    })
  },
  showdetail(){
    this.setData({
      detail:false,
      more:true
    })
  },
  hidedetail(){
    this.setData({
      detail:true,
      more:false
    })
  },
  tomy(){
    wx.navigateTo({
      url: '../myorder/myorders',
    })
  },
  zhifu(){
    this.setData({
      zhifu:true
    })
  },
  quxiao1(){
    this.setData({
      zhifu:false
    })
    wx.showToast({
      title: '取消支付',
      icon:'error',
      duration:1500
    })
  },
  zhifu1(){
    this.setData({
      zhifu:false
    })
    wx.showToast({
      title: '支付成功',
      icon:'success',
      duration:1500
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})