// pages/search/search.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goodlist:[],
    history:[{name:'莫匹罗星'},{name:'炉甘石'}],
    historyshow:true,
    inputValue: "",        //输入框输入的值
    replaceValue: "", //替换输入框的值
    remen:[{number:'1',title:"百多邦  莫匹罗星软膏2%*10g"},
      {number:'2',title:"匹得邦  莫匹罗星软膏2%*5g/支"},
      {number:'3',title:"匹得邦  莫匹罗星软膏2%*10g/支"},
      {number:'4',title:"鹏鹞  炉甘石洗剂100m1"},
      {number:'5',title:"星海  炉甘石洗剂100ml"}
      ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let that = this
    db.collection('goodss').get({
      success:res=> {
        console.log('商品获取成功',res)
        that.setData({
          goodlist:res.data,
        })
      },
      catch:res=> {
        console.log('商品获取失败！',res)
      }
    })

  },
  hide:function(){
    this.setData({
      historyshow:false
    })
  },
  show:function(){
    this.setData({
      historyshow:true
    })
  },

  getInputValue(e) {    
    console.log(e.detail.value)
    this.setData({
      inputValue: e.detail.value
    })
  },
  searchbegin: function (e) {
    var that = this
    var list = that.data.goodlist
    var arr=[]
    var value = that.data.inputValue
    for(let i=1;i<list.length;i++){
      var string = list[i].product_name;
      if(string.indexOf(value) >= 0){
        arr.splice(1,0,list[i])
      }
      console.log(arr)
    }
    if(value == "")
    {
      wx.showToast({
        title: '请输入商品名称',
        icon:'error',
        duration:1500
      })
    } else {
      that.setData({
        history:value
      })
      wx.setStorage({
        key:'historysearch',
        data:value
      })
      wx.showToast({
        title: '搜索成功',
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    /*let that = this
    wx.getStorage({
      key:'historysearch',
      success(res) {
        console.log('历史搜索记录',res.data);// res.data  A页面传过来的数据
        that.setData({
          history:res.data
        })
        // console.log(that.data.getData);
      }
    })*/
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})